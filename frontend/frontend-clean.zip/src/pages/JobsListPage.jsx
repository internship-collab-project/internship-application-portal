import { useEffect, useState } from 'react';
import Axios from '../services/Axios';
import useAuth from '../hooks/useAuth';

const JobsListPage = () => {
  const [jobs, setJobs] = useState([]);
  const { auth } = useAuth();

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const res = await Axios.get('/jobs');
        setJobs(res.data);
      } catch (err) {
        console.error('Failed to fetch jobs:', err);
      }
    };
    fetchJobs();
  }, []);

  const applyToJob = async (jobId) => {
    try {
      await Axios.post('/applications', { job_id: jobId }, {
        headers: {
          Authorization: `Bearer ${auth.accessToken}`
        }
      });
      alert('Application submitted!');
    } catch (err) {
      console.error('Failed to apply:', err);
    }
  };

  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold mb-4">Available Internships</h2>
      {jobs.map((job) => (
        <div key={job.id} className="mb-4 p-4 border border-gray-300 rounded">
          <h3 className="text-xl font-semibold">{job.title}</h3>
          <p>{job.description}</p>
          <p><strong>Deadline:</strong> {job.deadline}</p>
          {auth.roles?.includes('applicant') && (
            <button
              className="mt-2 bg-blue-600 text-white px-4 py-2 rounded"
              onClick={() => applyToJob(job.id)}>
              Apply
            </button>
          )}
        </div>
      ))}
    </div>
  );
};

export default JobsListPage;